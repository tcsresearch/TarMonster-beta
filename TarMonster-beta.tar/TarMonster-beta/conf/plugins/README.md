<h2> Plugins For TarMonster - WIP!</h2>
<hr>
<div id="Warning">
  <h3> :warning: This code is highly experimental and has NOT been fully implemented or tested yet. :warning: </h3>
  <h4>   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; These plugins are a Work In Progress (WIP) and considered highly experimental. </h4>
  <h4>   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; DO NOT USE ON ANY PRODUCTION SERVER OR SYSTEM ! </h4>
</div>
<hr>

<h4> These plugins, when finished, will allow TarMonster to work with various apps, such as EspoCRM, Apache, MySQL/MariaDB, and more. </h4>
<h4> <ins> Status Legend  </ins> </h4>
<ul>
  <li> <h4> :x:  Not Implemented. :x: </h4> </li>
  <li> <h4> :ballot_box_with_check: Update Config and Test. :ballot_box_with_check: </h4> </li>
  <li> <h4> :heavy_check_mark: Tested and Working as expected. :heavy_check_mark: </h4> </li>
</ul>
<hr>

<h4> Current Status Of Plugins</h4>
<ul>
  <li> <h4> Apache2:     :x:  Not Implemented. :x: </h4> </li>
  <li> <h4> phpSysInfo:     :x:  Not Implemented. :x: </h4> </li>
  <li> <h4> WordPress:     :x:  Not Implemented. :x: </h4> </li>
  <li> <h4> phpMyAdmin:     :x:  Not Implemented. :x: </h4> </li>
</ul>
<ul>
  <li> <h4> DB-Utility: :ballot_box_with_check: Update Config and Test. :ballot_box_with_check: </h4> </li>
  <li> <h4> EspoCRM: :ballot_box_with_check: Update Config and Test. :ballot_box_with_check: </h4> </li>
  <li> <h4> MantisBT: :ballot_box_with_check: Update Config and Test. :ballot_box_with_check: </h4> </li>
  </ul>
<hr>
