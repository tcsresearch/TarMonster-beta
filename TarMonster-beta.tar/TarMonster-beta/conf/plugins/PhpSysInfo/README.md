<h2> PHPSysInfo Plugin For TarMonster - WIP!</h2>
<hr>
<h3> :warning: This code is highly experiemental and has NOT been fully implemented or tested yet. :warning: </h3>
<hr>
<h4>STATUS: :x:  Not Implemented. :x: </h4>
