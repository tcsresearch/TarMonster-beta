<h2> MantisBT Plugin For TarMonster - WIP!</h2>
<hr>
<h3> :warning: This code is highly experiemental and has NOT been fully implemented or tested yet. :warning: </h3>
<hr>
<h4>STATUS: :ballot_box_with_check: Update Config and Test. :ballot_box_with_check: </h4>
