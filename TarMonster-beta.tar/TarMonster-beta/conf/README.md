# Configuration Folder For TarMonster
<hr>
This folder contains all the configuration files for TarMonster.
