cd BLING
pwd
#  source Cecho.bfunc CommandExists.bfunc Pause.bfunc Today.bfunc die.bfunc duls.bfunc
source `cat BLING-Functions.list`
cd -
