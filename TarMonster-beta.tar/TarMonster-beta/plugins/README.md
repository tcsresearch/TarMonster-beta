<h2> Plugins</h2>

> [!NOTE]
> The plugins folder for TarMonster.
<hr>

> [!WARNING]
> This code is highly experiemental and has NOT been fully implemented or tested yet.

> [!IMPORTANT]
> Testing has NOT been done yet, is NOT suitable for testing, and still lacks most features.

<hr>
<h2>Plugin Development Status</h2>

<h3>Web Applications</h3>

| Name | Description | Status
| --- | --- | --- |
| EspoCRM | Allows for upgrades of EspoCRM via TarMonster | In Development / Untested
| MantisBT | Allows for upgrades of MantisBT via TarMonster | In Development / Untested
| phpSysInfo | Allows for upgrades of phpSysInfo via TarMonster | Not Started Yet
| phpMyAdmin | Allows for upgrades of phpMyAdmin via TarMonster | Not Started Yet

<h3>Utilities</h3>

| Name | Description | Status
| --- | --- | --- |
| DB-Utility | Allows for backups/restores of MySQL/MariaDB via TarMonster | In Development / Untested

<h3>Folders</h3>

| Name | Description | Status
| --- | --- | --- |
| WebRoot | Allows for upgrades of Webroot folder via TarMonster | Not Started Yet
| UserFolders | Allows for backups & restores of User folders via TarMonster | Not Started Yet
| RPMBuildRoot | Allows for backups & restores of RPM BuildRoot folders via TarMonster | Not Started Yet
<hr>
