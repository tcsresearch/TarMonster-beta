## About This Folder
This /bin folder will likely be depricated in favor of the /functions, /conf, and /libraries folders in the near future.
