php -r "echo 'PHP Version: ' . phpversion();"
echo " "
