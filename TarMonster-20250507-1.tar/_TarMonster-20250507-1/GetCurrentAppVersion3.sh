php -r "echo 'Current App Version: '; "  && php crm.tcshosting.net/command.php version           

