# where [username] is a user name, e.g. admin.
php command.php SetPassword [username]
